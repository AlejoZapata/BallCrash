var searchData=
[
  ['score_5fp1_0',['score_p1',['../pantalla_digitales_8c.html#a41b5cb2d5daba6d35afc686061672c6e',1,'pantallaDigitales.c']]],
  ['score_5fp2_1',['score_p2',['../pantalla_digitales_8c.html#a8b7c92543c6e1b8edf27ea2bcfa83226',1,'pantallaDigitales.c']]],
  ['sm_5fws_2',['sm_ws',['../pantalla_digitales_8c.html#a07b1db91d45d9838e1650bb96a4fe520',1,'pantallaDigitales.c']]],
  ['strip0_3',['strip0',['../ws2812__parallel_8c.html#ab625c68c280f7ae8d28b9d04747dd23a',1,'ws2812_parallel.c']]],
  ['strip1_4',['strip1',['../ws2812__parallel_8c.html#a557635c5d3bd47fcb221e63083bb7fef',1,'ws2812_parallel.c']]],
  ['strips_5',['strips',['../ws2812__parallel_8c.html#a577633919c9d07ea6bed43eff282ce99',1,'ws2812_parallel.c']]]
];
