var searchData=
[
  ['pio_0',['pio',['../pantalla_digitales_8c.html#ac79a43604cef3e167780e935276174d0',1,'pantallaDigitales.c']]],
  ['planes_1',['planes',['../structvalue__bits__t.html#a6ade4ae2855381cbc086297fb6b09438',1,'value_bits_t']]],
  ['power_5ffreeze_5fused_5fp1_2',['power_freeze_used_p1',['../pantalla_digitales_8c.html#a29618bd592b4f725cd4c2202b7be2373',1,'pantallaDigitales.c']]],
  ['power_5ffreeze_5fused_5fp2_3',['power_freeze_used_p2',['../pantalla_digitales_8c.html#a8bb69532cffda760c94f69c82e1f34a3',1,'pantallaDigitales.c']]],
  ['power_5finvert_5fused_5fp1_4',['power_invert_used_p1',['../pantalla_digitales_8c.html#a4b622fa82e2985986d8f79f71047b580',1,'pantallaDigitales.c']]],
  ['power_5finvert_5fused_5fp2_5',['power_invert_used_p2',['../pantalla_digitales_8c.html#a4847f0701d1af2e5106810a0f0ab6118',1,'pantallaDigitales.c']]],
  ['prev_5fjoy_5fbtn_5fp1_6',['prev_joy_btn_p1',['../pantalla_digitales_8c.html#ab4babfce65c54158c2b666929473db34',1,'pantallaDigitales.c']]],
  ['prev_5fjoy_5fbtn_5fp2_7',['prev_joy_btn_p2',['../pantalla_digitales_8c.html#a15ee4c088e66e6f5457d4eaeb2596cab',1,'pantallaDigitales.c']]]
];
