var searchData=
[
  ['color_5fgol_5fb_0',['color_gol_b',['../pantalla_digitales_8c.html#a8e8b9f8b309ada0fe07ceccfe07997ad',1,'pantallaDigitales.c']]],
  ['color_5fgol_5fg_1',['color_gol_g',['../pantalla_digitales_8c.html#aa64d198aeb7f200b04b1d538b0bb7c73',1,'pantallaDigitales.c']]],
  ['color_5fgol_5fr_2',['color_gol_r',['../pantalla_digitales_8c.html#ac2ddb0e44c414443d9d75a3eb0c71a88',1,'pantallaDigitales.c']]]
];
