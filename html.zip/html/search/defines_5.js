var searchData=
[
  ['lcd_5faddr_0',['LCD_ADDR',['../pantalla_digitales_8c.html#a6a90c49be18cd45434c04afd79b0bf9d',1,'pantallaDigitales.c']]],
  ['lcd_5fbacklight_1',['LCD_BACKLIGHT',['../pantalla_digitales_8c.html#ac059d24dfe9c1e1f7c07cb7869a1833b',1,'pantallaDigitales.c']]],
  ['led_5fp1_5fa_2',['LED_P1_A',['../pantalla_digitales_8c.html#a4bd356d22b2632ee41c77d0e791ed353',1,'pantallaDigitales.c']]],
  ['led_5fp1_5fb_3',['LED_P1_B',['../pantalla_digitales_8c.html#a4db9d356d331b80d992ad1aecc202971',1,'pantallaDigitales.c']]],
  ['led_5fp2_5fa_4',['LED_P2_A',['../pantalla_digitales_8c.html#a80f6a230cd7120755f92262ca43255bb',1,'pantallaDigitales.c']]],
  ['led_5fp2_5fb_5',['LED_P2_B',['../pantalla_digitales_8c.html#a6e1371c3726469577b8aa3d5b5058a52',1,'pantallaDigitales.c']]]
];
