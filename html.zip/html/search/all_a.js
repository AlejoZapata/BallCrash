var searchData=
[
  ['offset_5fws_0',['offset_ws',['../pantalla_digitales_8c.html#a22fcf6088595263ae60b2c0f3c140455',1,'pantallaDigitales.c']]],
  ['output_5fstrips_5fdma_1',['output_strips_dma',['../ws2812__parallel_8c.html#a720167f5365fba6fe283cdd16988ae2d',1,'ws2812_parallel.c']]]
];
