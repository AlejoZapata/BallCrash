var searchData=
[
  ['transform_5fstrips_0',['transform_strips',['../ws2812__parallel_8c.html#a0e66516622126993409a4bd51a3e8b39',1,'ws2812_parallel.c']]],
  ['transistor_5fp1_5fpin_1',['TRANSISTOR_P1_PIN',['../pantalla_digitales_8c.html#ad550207d037c71bb156da6def09d5c2f',1,'pantallaDigitales.c']]],
  ['transistor_5fp2_5fpin_2',['TRANSISTOR_P2_PIN',['../pantalla_digitales_8c.html#a31ce087729a4b9b87203bc9c2fcb73b7',1,'pantallaDigitales.c']]],
  ['trophy_5fframes_3',['trophy_frames',['../pantalla_digitales_8c.html#a54f5e30d540e45f45942876f1407e336',1,'pantallaDigitales.c']]]
];
