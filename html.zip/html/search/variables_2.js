var searchData=
[
  ['data_0',['data',['../structstrip__t.html#abe222f6d3581e7920dcad5306cc906a8',1,'strip_t']]],
  ['data_5flen_1',['data_len',['../structstrip__t.html#afc754b33dec99353ec610d3e63a50ff1',1,'strip_t']]],
  ['duracion_5fanimacion_5fgol_2',['duracion_animacion_gol',['../pantalla_digitales_8c.html#a0b796c2835323d4cdd42de9ca16951ae',1,'pantallaDigitales.c']]]
];
