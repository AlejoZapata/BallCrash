var searchData=
[
  ['value_5fbits_5ft_0',['value_bits_t',['../structvalue__bits__t.html',1,'']]],
  ['vrx_5fp1_5fpin_1',['VRX_P1_PIN',['../pantalla_digitales_8c.html#adf4d636e7053a6c86782cf86b34368e8',1,'pantallaDigitales.c']]],
  ['vrx_5fp2_5fpin_2',['VRX_P2_PIN',['../pantalla_digitales_8c.html#a06a940886e056b60db549e8249954248',1,'pantallaDigitales.c']]]
];
