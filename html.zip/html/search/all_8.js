var searchData=
[
  ['main_0',['main',['../pantalla_digitales_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;pantallaDigitales.c'],['../ws2812_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;ws2812.c'],['../ws2812__parallel_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;ws2812_parallel.c']]],
  ['motor_5fcontrol_5fpwm_1',['motor_control_pwm',['../pantalla_digitales_8c.html#a8896e6db3e77d64a227ae705a7dc7ce9',1,'pantallaDigitales.c']]]
];
