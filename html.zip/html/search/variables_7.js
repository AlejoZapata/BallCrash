var searchData=
[
  ['offset_5fws_0',['offset_ws',['../pantalla_digitales_8c.html#a22fcf6088595263ae60b2c0f3c140455',1,'pantallaDigitales.c']]]
];
