var searchData=
[
  ['deadzone_0',['DEADZONE',['../pantalla_digitales_8c.html#a08308e05fa7bbbfcf4ffb7a08aa68fa1',1,'pantallaDigitales.c']]]
];
