var searchData=
[
  ['num_5fpixels_0',['NUM_PIXELS',['../pantalla_digitales_8c.html#a893011783fefc21f30baf08142cd3c35',1,'NUM_PIXELS:&#160;pantallaDigitales.c'],['../ws2812_8c.html#a893011783fefc21f30baf08142cd3c35',1,'NUM_PIXELS:&#160;ws2812.c']]]
];
