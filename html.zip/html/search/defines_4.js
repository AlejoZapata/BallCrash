var searchData=
[
  ['i2c_5flcd1_0',['I2C_LCD1',['../pantalla_digitales_8c.html#ae312e5c465c4da2aa7c5da4a1531c840',1,'pantallaDigitales.c']]],
  ['i2c_5flcd2_1',['I2C_LCD2',['../pantalla_digitales_8c.html#a229a49cbb70cb588cad8aa03f545d450',1,'pantallaDigitales.c']]],
  ['in1_5fp1_2',['IN1_P1',['../pantalla_digitales_8c.html#a7b766843ba430d818c78037f0aea9cba',1,'pantallaDigitales.c']]],
  ['in1_5fp2_3',['IN1_P2',['../pantalla_digitales_8c.html#a11f5a1f653276448d6282c6ebaed4423',1,'pantallaDigitales.c']]],
  ['in2_5fp1_4',['IN2_P1',['../pantalla_digitales_8c.html#a2939e0fb1324cf8ef7ee22b9d650d01c',1,'pantallaDigitales.c']]],
  ['in2_5fp2_5',['IN2_P2',['../pantalla_digitales_8c.html#a4139640c8facb05626b1105ef92f4b94',1,'pantallaDigitales.c']]],
  ['is_5frgbw_6',['IS_RGBW',['../pantalla_digitales_8c.html#a493b9b7cc0c4de9e5d832a5b9c8fe0f0',1,'IS_RGBW:&#160;pantallaDigitales.c'],['../ws2812_8c.html#a493b9b7cc0c4de9e5d832a5b9c8fe0f0',1,'IS_RGBW:&#160;ws2812.c']]]
];
