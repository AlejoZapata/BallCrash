var searchData=
[
  ['reset_5fdelay_5falarm_5fid_0',['reset_delay_alarm_id',['../ws2812__parallel_8c.html#ae8ec39342286563144028f24b7b2c506',1,'ws2812_parallel.c']]],
  ['reset_5fdelay_5fcomplete_1',['reset_delay_complete',['../ws2812__parallel_8c.html#a13c7eeb8ee893b70caf2145a7f2edbd0',1,'ws2812_parallel.c']]]
];
