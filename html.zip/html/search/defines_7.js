var searchData=
[
  ['pulsador_5fp1_5fpin_0',['PULSADOR_P1_PIN',['../pantalla_digitales_8c.html#a78919b8b171e9d6e2c28f3bc0cdeca27',1,'pantallaDigitales.c']]],
  ['pulsador_5fp2_5fpin_1',['PULSADOR_P2_PIN',['../pantalla_digitales_8c.html#a7271d672114bcaff0c845206a60043a9',1,'pantallaDigitales.c']]],
  ['pwm_5fp1_5fpin_2',['PWM_P1_PIN',['../pantalla_digitales_8c.html#ae9f6a13d774347787d4620da96af2f06',1,'pantallaDigitales.c']]],
  ['pwm_5fp2_5fpin_3',['PWM_P2_PIN',['../pantalla_digitales_8c.html#ac65c5a899f72c99d671a5a6890f539b2',1,'pantallaDigitales.c']]],
  ['pwm_5fval_4',['PWM_VAL',['../pantalla_digitales_8c.html#ab3e76edff1082dded6842ff771bc8803',1,'pantallaDigitales.c']]]
];
