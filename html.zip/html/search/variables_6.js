var searchData=
[
  ['last_5fjoy_5fpress_5fp1_0',['last_joy_press_p1',['../pantalla_digitales_8c.html#a730e66f99aa41ae308586dc4f5cca53b',1,'pantallaDigitales.c']]],
  ['last_5fjoy_5fpress_5fp2_1',['last_joy_press_p2',['../pantalla_digitales_8c.html#ac0592098648ccfe4df3f824069f32805',1,'pantallaDigitales.c']]],
  ['last_5fsensor1_2',['last_sensor1',['../pantalla_digitales_8c.html#a5dcd4972cf794f40c48fefacdebad7a6',1,'pantallaDigitales.c']]],
  ['last_5fsensor2_3',['last_sensor2',['../pantalla_digitales_8c.html#a7b434bef83fb7a0db1af95d3df27b73f',1,'pantallaDigitales.c']]],
  ['lcd_5fmsg_4',['lcd_msg',['../pantalla_digitales_8c.html#a07f0c5de2ece18be5b13154eb238ff98',1,'pantallaDigitales.c']]],
  ['lcd_5fmsg_5ftimeout_5',['lcd_msg_timeout',['../pantalla_digitales_8c.html#a841d60aa1e2822e688ce64407f837d88',1,'pantallaDigitales.c']]]
];
