var searchData=
[
  ['gol_5fde_5fp1_0',['gol_de_p1',['../pantalla_digitales_8c.html#a49c6567742059f2e0a1bbec0ccebbdf4',1,'pantallaDigitales.c']]]
];
