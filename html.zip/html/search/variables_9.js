var searchData=
[
  ['reset_5fdelay_5falarm_5fid_0',['reset_delay_alarm_id',['../ws2812__parallel_8c.html#ae8ec39342286563144028f24b7b2c506',1,'ws2812_parallel.c']]]
];
