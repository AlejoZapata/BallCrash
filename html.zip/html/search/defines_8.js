var searchData=
[
  ['scl_5flcd1_0',['SCL_LCD1',['../pantalla_digitales_8c.html#adc6bda15192dae7bcce43e7515d0d944',1,'pantallaDigitales.c']]],
  ['scl_5flcd2_1',['SCL_LCD2',['../pantalla_digitales_8c.html#a42dc202f6e65f6fd5efb1f564fe0c2d7',1,'pantallaDigitales.c']]],
  ['sda_5flcd1_2',['SDA_LCD1',['../pantalla_digitales_8c.html#a3b80198161152b1981b8d30d2c39af6b',1,'pantallaDigitales.c']]],
  ['sda_5flcd2_3',['SDA_LCD2',['../pantalla_digitales_8c.html#a43dd46ae165efee61a4d55a8ca5285df',1,'pantallaDigitales.c']]],
  ['sensor_5fp1_5fpin_4',['SENSOR_P1_PIN',['../pantalla_digitales_8c.html#a8890772bb2dc162510722cf57c7cd45f',1,'pantallaDigitales.c']]],
  ['sensor_5fp2_5fpin_5',['SENSOR_P2_PIN',['../pantalla_digitales_8c.html#a10b4b066bd8f8358c64380bf8be6589f',1,'pantallaDigitales.c']]],
  ['sw_5fp1_6',['SW_P1',['../pantalla_digitales_8c.html#a41bbc2dfe8eca8af26bc2ea73d03ab21',1,'pantallaDigitales.c']]],
  ['sw_5fp2_7',['SW_P2',['../pantalla_digitales_8c.html#ad73b29d2f0981513f5ef51b926d4048f',1,'pantallaDigitales.c']]]
];
