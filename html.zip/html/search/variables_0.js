var searchData=
[
  ['animacion_5fgol_5factiva_0',['animacion_gol_activa',['../pantalla_digitales_8c.html#a5446598c13e67dcf1a3820c8a7834ea2',1,'pantallaDigitales.c']]],
  ['animacion_5fgol_5finicio_1',['animacion_gol_inicio',['../pantalla_digitales_8c.html#a0bc2d2db25ce27f12443e9a22a81e073',1,'pantallaDigitales.c']]],
  ['awaiting_5fdouble_5fp1_2',['awaiting_double_p1',['../pantalla_digitales_8c.html#a34b3863f99c607325c402124ce6b552b',1,'pantallaDigitales.c']]],
  ['awaiting_5fdouble_5fp2_3',['awaiting_double_p2',['../pantalla_digitales_8c.html#a5040d5ba703d9cc2ba817bec10fe6f1b',1,'pantallaDigitales.c']]]
];
