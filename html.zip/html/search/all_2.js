var searchData=
[
  ['data_0',['data',['../structstrip__t.html#abe222f6d3581e7920dcad5306cc906a8',1,'strip_t']]],
  ['data_5flen_1',['data_len',['../structstrip__t.html#afc754b33dec99353ec610d3e63a50ff1',1,'strip_t']]],
  ['deadzone_2',['DEADZONE',['../pantalla_digitales_8c.html#a08308e05fa7bbbfcf4ffb7a08aa68fa1',1,'pantallaDigitales.c']]],
  ['dither_5fvalues_3',['dither_values',['../ws2812__parallel_8c.html#a20792e653d1809363b86422b801043f0',1,'ws2812_parallel.c']]],
  ['dma_5fcomplete_5fhandler_4',['dma_complete_handler',['../ws2812__parallel_8c.html#a068db1e8bb8c7ccb5086045cc56c6657',1,'ws2812_parallel.c']]],
  ['dma_5finit_5',['dma_init',['../ws2812__parallel_8c.html#a4118777055981b989ba5a9082470bff9',1,'ws2812_parallel.c']]],
  ['draw_5fframe_6',['draw_frame',['../pantalla_digitales_8c.html#a8f7acda4de2ff9ede5fca68d2db09959',1,'pantallaDigitales.c']]],
  ['duracion_5fanimacion_5fgol_7',['duracion_animacion_gol',['../pantalla_digitales_8c.html#a0b796c2835323d4cdd42de9ca16951ae',1,'pantallaDigitales.c']]]
];
