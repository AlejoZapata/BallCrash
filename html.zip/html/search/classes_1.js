var searchData=
[
  ['value_5fbits_5ft_0',['value_bits_t',['../structvalue__bits__t.html',1,'']]]
];
