var searchData=
[
  ['transform_5fstrips_0',['transform_strips',['../ws2812__parallel_8c.html#a0e66516622126993409a4bd51a3e8b39',1,'ws2812_parallel.c']]]
];
