var searchData=
[
  ['transistor_5fp1_5fpin_0',['TRANSISTOR_P1_PIN',['../pantalla_digitales_8c.html#ad550207d037c71bb156da6def09d5c2f',1,'pantallaDigitales.c']]],
  ['transistor_5fp2_5fpin_1',['TRANSISTOR_P2_PIN',['../pantalla_digitales_8c.html#a31ce087729a4b9b87203bc9c2fcb73b7',1,'pantallaDigitales.c']]]
];
