var searchData=
[
  ['center_5fp1_0',['CENTER_P1',['../pantalla_digitales_8c.html#a55fa93c874097b848cbc39e3b1e3b9a0',1,'pantallaDigitales.c']]],
  ['center_5fp2_1',['CENTER_P2',['../pantalla_digitales_8c.html#ae614c6dd88f00859f86778bd8b6594fc',1,'pantallaDigitales.c']]]
];
