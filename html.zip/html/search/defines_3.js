var searchData=
[
  ['gol_5fboton_5fazul_0',['GOL_BOTON_AZUL',['../ws2812_8c.html#a634c0750d663ebc58729038d688d53d3',1,'ws2812.c']]],
  ['gol_5fboton_5frojo_1',['GOL_BOTON_ROJO',['../ws2812_8c.html#aea2267d2723ce37a99e3aa1a6dc21a6b',1,'ws2812.c']]]
];
