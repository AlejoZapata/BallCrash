var searchData=
[
  ['core1_5fws2812_5floop_0',['core1_ws2812_loop',['../pantalla_digitales_8c.html#a565b83f99f0d688d17fa57c2a264d9a2',1,'pantallaDigitales.c']]]
];
