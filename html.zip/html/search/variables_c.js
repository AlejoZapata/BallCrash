var searchData=
[
  ['ws_5fpixels_0',['ws_pixels',['../pantalla_digitales_8c.html#a6d973b2aca7ea5da6a7d2e85bb4fa542',1,'pantallaDigitales.c']]]
];
