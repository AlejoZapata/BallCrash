var searchData=
[
  ['invert_5fstart_5fp1_0',['invert_start_p1',['../pantalla_digitales_8c.html#a086613ada147d6220ec9e923f9791b78',1,'pantallaDigitales.c']]],
  ['invert_5fstart_5fp2_1',['invert_start_p2',['../pantalla_digitales_8c.html#ad2740041897af6e3851903a11f3be192',1,'pantallaDigitales.c']]]
];
