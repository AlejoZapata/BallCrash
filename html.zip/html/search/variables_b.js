var searchData=
[
  ['trophy_5fframes_0',['trophy_frames',['../pantalla_digitales_8c.html#a54f5e30d540e45f45942876f1407e336',1,'pantallaDigitales.c']]]
];
