var searchData=
[
  ['show_5fwinner_0',['show_winner',['../pantalla_digitales_8c.html#a1e9aca11c0bf468a04ac0b3547ff30a1',1,'pantallaDigitales.c']]]
];
