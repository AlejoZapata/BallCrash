var searchData=
[
  ['strip_5ft_0',['strip_t',['../structstrip__t.html',1,'']]]
];
