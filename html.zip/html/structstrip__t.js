var structstrip__t =
[
    [ "data", "structstrip__t.html#abe222f6d3581e7920dcad5306cc906a8", null ],
    [ "data_len", "structstrip__t.html#afc754b33dec99353ec610d3e63a50ff1", null ],
    [ "frac_brightness", "structstrip__t.html#a17900fa710027a7c8319b96b721e9e04", null ]
];