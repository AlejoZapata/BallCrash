var ws2812_8c =
[
    [ "GOL_BOTON_AZUL", "ws2812_8c.html#a634c0750d663ebc58729038d688d53d3", null ],
    [ "GOL_BOTON_ROJO", "ws2812_8c.html#aea2267d2723ce37a99e3aa1a6dc21a6b", null ],
    [ "IS_RGBW", "ws2812_8c.html#a493b9b7cc0c4de9e5d832a5b9c8fe0f0", null ],
    [ "NUM_PIXELS", "ws2812_8c.html#a893011783fefc21f30baf08142cd3c35", null ],
    [ "WS2812_PIN", "ws2812_8c.html#af75dc8bf5891f41c539ef9b8ebd3d1c3", null ],
    [ "main", "ws2812_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "pattern_futbolito", "ws2812_8c.html#a6a1548f5d7d9383119bc92d116327ad4", null ],
    [ "pattern_gol", "ws2812_8c.html#a3646f60c0946ac58e38418e95314a331", null ]
];