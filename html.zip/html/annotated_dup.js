var annotated_dup =
[
    [ "strip_t", "structstrip__t.html", "structstrip__t" ],
    [ "value_bits_t", "structvalue__bits__t.html", "structvalue__bits__t" ]
];