var dir_6bca89d07bb3dcc5b842af9bc39dd741 =
[
    [ "generated", "dir_72ac74f4812c2247d85b5bb55ceb455a.html", "dir_72ac74f4812c2247d85b5bb55ceb455a" ],
    [ "pantallaDigitales.c", "pantalla_digitales_8c.html", "pantalla_digitales_8c" ],
    [ "ws2812.c", "ws2812_8c.html", "ws2812_8c" ],
    [ "ws2812_parallel.c", "ws2812__parallel_8c.html", "ws2812__parallel_8c" ]
];