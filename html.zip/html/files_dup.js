var files_dup =
[
    [ "pantallaDigitales", "dir_6bca89d07bb3dcc5b842af9bc39dd741.html", "dir_6bca89d07bb3dcc5b842af9bc39dd741" ]
];